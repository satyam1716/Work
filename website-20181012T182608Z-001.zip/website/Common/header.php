<header id="header" id="home">
			    <div class="container main-menu">
			    	<div class="row align-items-center justify-content-between d-flex">
				      <div id="logo">
				        <a href="index - Copy.php"><img src="img/logo/newlog.jpg" alt="" title="" /></a>  
				      </div>
				      <nav id="nav-menu-container">
				        <ul class="nav-menu">
				          <li class="menu-active"><a href="#home">Home</a></li>
				          <li><a href="#about">About</a></li>
				          <li><a href="#service">Services</a></li>
						   <li><a href="#why_us">Why us</a></li>
				          <li><a href="#projects">Projects</a></li>
				         	
                          <li><a href="#team">Team</a></li>
                       <!--   <li><a href="#portfolio">Portfolio</a></li>		-->				  
				          <li><a href="#contact">Contact Us</a></li>
				        </ul>
				      </nav><!-- #nav-menu-container -->		    		
			    	</div>
			    </div>
			  </header>