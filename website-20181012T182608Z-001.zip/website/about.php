	<!DOCTYPE html>
	<html lang="zxx" class="no-js">
	<head>
       <?php include('Common/head.php');?>
		</head>
		<body>	
		<?php include('Common/header.php');?>
			  <!-- #header -->
			  
			  
			    
			<!-- start banner Area -->
			<section class="banner-area-about relative" id="home">	
				<div class="overlay overlay-bg"></div>
				<div class="container">				
					<div class="row d-flex align-items-center justify-content-center">
						<div class="about-content col-lg-12">
							<h1 class="text-white">
								About Us				
							</h1>	
							<p class="text-white link-nav"><a href="index">Home </a>  <span class="lnr lnr-arrow-right"></span>  <a href="about"> About Us</a></p>
						</div>	
					</div>
				</div>
			</section>
			<!-- End banner Area -->	

		<!----- About area ----->
			
			<section  class="about-video-area section-gap">
				<div class="container">
					<div class="row align-items-center">
						<div class="col-lg-6 about-video-left">
							<h6 class="text-uppercase">website design according to your demands</h6>
							<h1>
								Turn your Idea Into Fantastic Website Design or Mobile App Development!
							</h1>
							<p>
								<span>Website Design and Development | Android Development </span><br>
								<span>Our company is small and nimble, thus we can give you the attention you expect and deserve.</span>
							</p>
							<p>
								Satyam Softwares company incorporated in 2017. We are a team of highly skilled developers, UI/UX designers, Project Managers and Technology Consultants.
							</p>
							
						</div>
						<div class="col-lg-6 about-video-right justify-content-center align-items-center d-flex relative">
							<div class="overlay overlay-bg"></div>
							<a class="play-btn" href="https://www.youtube.com/watch?v=gQRsgFw7tcg"><img class="img-fluid mx-auto" src="img/play-btn.png" alt=""></a>
						</div>
					</div>
				</div>	
			</section>
			
			<!----- End About area ----->					


			<!-- Start brands Area -->
			<section class="brands-area pb-60 pt-60">
				<div class="container no-padding">
					<div class="brand-wrap">
						<div class="row align-items-center active-brand-carusel justify-content-start no-gutters">
							<div class="col single-brand">
								<a href="#"><img class="mx-auto" src="img/l1.png" alt=""></a>
							</div>
							<div class="col single-brand">
								<a href="#"><img class="mx-auto" src="img/l2.png" alt=""></a>
							</div>
							<div class="col single-brand">
								<a href="#"><img class="mx-auto" src="img/l3.png" alt=""></a>
							</div>
							<div class="col single-brand">
								<a href="#"><img class="mx-auto" src="img/l4.png" alt=""></a>
							</div>
							<div class="col single-brand">
								<a href="#"><img class="mx-auto" src="img/l5.png" alt=""></a>
							</div>								
						</div>																			
					</div>
				</div>	
			</section>
			<!-- End brands Area -->											
				
			  
			  
		<!-- start footer Area -->		
<?php include('Common/footer.php');?>
			
			
		</body>
	</html>