 $('#form_change').on('change', function() {
    alert( this.value ); // or $(this).val()
  if(this.value == "1") {
    $('#static').show();
    $('#dynamic').hide();
  } else{
    $('#static').hide();
    $('#dynamic').show();
  }
});