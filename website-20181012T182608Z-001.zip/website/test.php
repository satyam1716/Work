<html lang="zxx" class="no-js">
<head>
<style>
	
body {
  background-color: #3FB;
  text-align: center;
  line-height: 100vh;
}


.box {
  position:relative;
  vertical-align: middle;
  color: #0b7;
  display: inline-block;
  height: 60px;
  line-height: 60px;
  text-align: center;
  transition: 0.5s;
  padding: 0 20px;
  cursor: pointer;
  border: 2px solid #0b7;
  -webkit-transition:0.5s;
}

.box:hover {
  border: 2px solid rgba(0,160,80,0);
  color: #FFF;
}

.box::before, .box::after {
  width: 100%;
  height:100%;
  z-index: 3;
  content:'';
  position: absolute;
  top:0;
  left:0;
  box-sizing: border-box;
  -webkit-transform: scale(0);
  transition: 0.5s;
}


.bar::before {
  border-bottom: 3px solid #FFF;
  border-left: 3px solid #FFF;
  -webkit-transform-origin: 100% 0%;
}

.bar::after {
  border-top: 3px solid #FFF;
  border-right: 3px solid #FFF;
  -webkit-transform-origin: 0% 100%;
}



.box:hover::after, .box:hover::before {
  -webkit-transform: scale(1);
}



</style>
</head>
<body>


	<a href='https://lesmoffat.co.uk' target='_BLANK'>
	  <div class='box bar'>
		bar
	  </div>
	</a>


</body>
</html>