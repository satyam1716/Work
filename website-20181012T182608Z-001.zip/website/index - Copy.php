	<!DOCTYPE html>
	<html lang="zxx" class="no-js">
	<head>
       <?php include('Common/head.php');?>
		</head>
		<body>	
		<?php include('Common/header.php');?>
			  <!-- #header -->

			<!-- start banner Area -->
			<section class="banner-area relative" id="home">
				<div class="overlay overlay-bg"></div>
				<div class="container">
					<div class="row fullscreen d-flex justify-content-center align-items-center">
						<div class="banner-content col-lg-9 col-md-12 justify-content-center ">
							<h1>
								STARTING A NEW JOURNEY!!	
							</h1>
							<p class="text-white mx-auto">
								Need to launch your website? We are an amazing team behind to help you design and develop your website.
							</p>
							 <a href="#" class="primary-btn header-btn text-uppercase mt-10" data-toggle="modal" data-target="#myModal">Request a quote</a> 
						</div>											
					</div>
				</div>
			</section>
			<!-- End banner Area -->
			
			<!----- About area ----->
			
			<section  class="about-video-area section-gap" id="about">
				<div class="container">
					<div class="row align-items-center">
						<div class="col-lg-6 about-video-left">
							<h6 class="text-uppercase">website design according to your demands</h6>
							<h1>
								Turn your Idea Into Fantastic Website Design or Mobile App Development!
							</h1>
							<p>
								<span>Website Design and Development | Android Development </span><br>
								<span>Our company is small and nimble, thus we can give you the attention you expect and deserve.</span>
							</p>
							<p>
								Satyam Softwares company incorporated in 2017. We are a team of highly skilled developers, UI/UX designers, Project Managers and Technology Consultants.
							</p>
							<!--<a class="primary-btn mt-30" href="about">Get Started Now</a>-->
						</div>
						<div class="col-lg-6 about-video-right justify-content-center align-items-center d-flex relative">
							<div class="overlay overlay-bg"></div>
							<a class="play-btn" href="https://www.youtube.com/watch?v=gQRsgFw7tcg"><img class="img-fluid mx-auto" src="img/play-btn.png" alt=""></a>
						</div>
					</div>
				</div>	
			</section>
			
			<!----- End About area ----->
			
				
			<!-- Start feature Area -->
			<section class="feature-area section-gap" id="service">
				<div class="container">
					<div class="row d-flex justify-content-center">
						<div class="col-md-12 pb-40 header-text text-center">
							<h1 class="pb-10 text-black">Some Features that Made us Unique</h1>
							<p class="text-black">
								Who are in extremely love with eco friendly system.
							</p>
						</div>
					</div>							
					<div class="row">
						<div class="col-lg-4 col-md-6">
							<div class="single-feature">
								<a href="#" class="title d-flex flex-row align-items-center">
									<i style="font-size: 28px; color: black; margin-right: 15px;" class="fa fa-laptop" aria-hidden="true"></i>
									<h4>Static/Dynamic Website Design & Development</h4>
								</a>
								<p>
									Designs by Satyam softwares aloud for its creativity. Be it a website, logos or brochures, the designs are simple but powerful, a perfect recipe for mesmerizing user interface. This explains Satyam softwares’s success as a top rated software agency in digital marketing and web designing.
								</p>
							</div>
						</div>
						<div class="col-lg-4 col-md-6">
							<div class="single-feature">
								<a href="#" class="title d-flex flex-row align-items-center">
									<span class="lnr lnr-license"></span>
									<h4>Ecommerce Development</h4>
								</a>
								<p>
									Every business loves the word ‘sales’. Our ecommerce sites provide the business a supplementary sales channel with infinite reach for convenience in sales and customer service. We go the extra mile for each responsive ecommerce websites to convert clicks to clients.
								</p>
							</div>
						</div>
						<div class="col-lg-4 col-md-6">
							<div class="single-feature">
								<a href="#" class="title d-flex flex-row align-items-center">
									<i style="font-size: 28px; color: black; margin-right: 15px;" class="fa fa-wordpress" aria-hidden="true"></i>
									<h4>Wordpress Website Development</h4>
								</a>
							<li>Custom WordPress Development</li>
							<li>Plugin Development</li>
							<li>Theme Development</li>
							<li>WordPress Design & Development</li>
							<li>Responsive WordPress Website</li>
							</div>
						</div>						
						
						<div class="col-lg-4 col-md-6">
							<div class="single-feature">
								<a href="#" class="title d-flex flex-row align-items-center">
									<span class="lnr lnr-diamond"></span>
									<h4>PHP Website Development</h4>
								</a>
								<p>
									As they say - "Mobile First", it is impossible to imagine mobile without web. We build robust mobile backend as well as do develop web applications. With programming and web design experience of years, companies hire us for our expertise in PHP, .NET, Java to build CMS, E-commerce and business applications. Our web developers build front-end, back-end and APIs as per the solution to be created OR can engage on dedicated bases to augment your current development team.
								</p>
							</div>
						</div>
						<div class="col-lg-4 col-md-6">
							<div class="single-feature">
								<a href="#" class="title d-flex flex-row align-items-center">
									<span class="lnr lnr-bubble"></span>
									<h4>UI & UX Design</h4>
								</a>
								<p>
									We map the journey between consumers and digital products; transform them into premium UX solutions to revolutionize business.
								</p>
							</div>
						</div>	
						<div class="col-lg-4 col-md-6">
							<div class="single-feature">
								<a href="#" class="title d-flex flex-row align-items-center">
									<span class="lnr lnr-rocket"></span>
									<h4>SEO & SMO Optimization</h4>
								</a>
								<p>
									Here’s the best for the last after all this is our core. We love traffic and our proposition starts from the clicks and stretches to make them clients. Rest assured to be among the Google top rankers with our Search Engine Optimization. Don’t be surprised to be an online social celebrity with social media raving about you with our Social Media Marketing
								</p>
							</div>
						</div>

					</div>
				</div>	
			</section>
			<!-- End feature Area -->
<section class="service-area section-gap" id="why_us">
				<div class="container">
					<div class="row justify-content-center">
						<div class="col-md-12 pb-50 header-text text-center">
							<h1 class="mb-10">Creativity doesn’t need complexity but simplicity<br /> We are creators of Simple and Effecient Websites and Applications</h1>
						<!--	<p>
							Creativity doesn’t need complexity but simplicity: We are creators of Simple but not Easy Website.
							</p>  -->
						</div>
					</div>						
					<div class="row">
                        <div class="col-lg-12">
							<img class="content-image img-fluid d-block mx-auto" src="img/content/choose3.png" alt="" style="width:100%;">
						</div>	
                     <!--   <div class="col-lg-6">
							<div class="diamond" style="margin-left: 90px;">
							<p class="square">WE DESIGN FOR <br/>ALL DEVICES</p>
							</div>
							<div class="diamond">
							<p class="square">OUR TEAM IS PROFESSIONAL</p>
							</div>
							<div class="diamond">
							<p class="square">WE PROVIDE TURNKEY SOLUTIONS</p>
							</div>
							
							<div class="diamond" style="margin-left: 90px;">
							<p class="square" style="margin: 40px 0px 0px 5px;">OUR ECOMMERCE SOLUTIONS <br/>FETCHES <br/>BUSINESS</p>
							</div>
							<div class="diamond">
							<p class="square">WE WORK TO <br/>EXCEL AND <br/>IMPROVE</p>
							</div>
							<div class="diamond">
							<p class="square">WE DRINK A LOT OF COFFEE</p>
							</div>
						</div>	-->						
					</div>
				</div>	
			</section>			
			<!-- Projects -->
			<section class="gallery-area" id="projects">
				<div class="container">				
					<div class="row">
						<div class="col-md-12 pb-50 header-text text-center">
							<h1 class="mb-10 projects">Watch us rock your world with our web design capabilities</h1>
							<p>
								We design your future.
                                We design your success.
							</p>
						</div>
						<div class="col-lg-4">
							<div class="single-gallery">
								<div class="content">
								    <a href="#" target="_blank">
								      <div class="content-overlay"></div>
								  		 <img class="content-image img-fluid d-block mx-auto" src="img/g2.jpg" alt="">
								      </a><div class="content-details fadeIn-bottom"><a href="#" target="_blank">
								        <h3 class="content-title mx-auto">SK Group</h3>
								        </a><a href="http://skopl.in/" class="primary-btn text-uppercase mt-20">Visit Site</a>
								      </div>
								    
								</div>
							</div>
						</div>	
						<div class="col-lg-4">
							<div class="single-gallery">
								<div class="content">
								    <a href="#" target="_blank">
								      <div class="content-overlay"></div>
								  		 <img class="content-image img-fluid d-block mx-auto" src="img/g3.jpg" alt="">
								      </a><div class="content-details fadeIn-bottom"><a href="#" target="_blank">
								        <h3 class="content-title mx-auto">SNS Bank</h3>
								        </a><a href="http://snsbankchh.com/" class="primary-btn text-uppercase mt-20">More Details</a>
								      </div>
								    
								</div>
							</div>
						</div>
						<div class="col-lg-4">
							<div class="single-gallery">
								<div class="content">
								    <a href="#" target="_blank">
								      <div class="content-overlay"></div>
								  		 <img class="content-image img-fluid d-block mx-auto" src="img/g3.jpg" alt="">
								      </a><div class="content-details fadeIn-bottom"><a href="#" target="_blank">
								        <h3 class="content-title mx-auto">Mumbaidera</h3>
								        </a><a href="http://hiteshsolutions.com/customers/mumbaidera/" class="primary-btn text-uppercase mt-20">More Details</a>
								      </div>
								    
								</div>
							</div>
						</div>
																		
					</div>
				</div>	
			</section>
			<!-- End Projects -->
			
			<!-- Start service Area -->
			
			<!-- End service Area -->
			<!---  Service  -->
<!--		<section class="service-area" id="team">
				<div class="container">	
                    <div class="col-md-12 pb-50 header-text text-center">
							<h1 class="mb-10">Team Members</h1>
						</div>				
					<div class="row">
						<div class="col-lg-4">
						  <div class='box bar'>
							<img class="content-image img-fluid d-block mx-auto" src="img/g3.jpg" alt="">
						  </div>
						   <div class="details team_members">
							<a href="#"><h4 class="title">Member </h4></a>
									<p>
										Acres of Diamonds… you’ve read the famous story, or at least had it related to you. A farmer.
									</p>
								</div>
							</div>
							<div class="col-lg-4">
							  <div class='box bar'>
								<img class="content-image img-fluid d-block mx-auto" src="img/g3.jpg" alt="">
							  </div>
							  <div class="details team_members">
						      	<a href="#"><h4 class="title">Member </h4></a>
									<p>
										Acres of Diamonds… you’ve read the famous story, or at least had it related to you. A farmer.
									</p>
								</div>
							</div>
							<div class="col-lg-4">
							  <div class='box bar'>
								<img class="content-image img-fluid d-block mx-auto" src="img/g3.jpg" alt="">
							  </div>
							   <div class="details team_members">
							<a href="#"><h4 class="title">Member </h4></a>
									<p>
										Acres of Diamonds… you’ve read the famous story, or at least had it related to you. A farmer.
									</p>
								</div>
							</div>
									</div>
										</div>	
									</section>     -->
			<section  class="about-video-area section-gap" style="padding: 35px 0;" id="team">
				<div class="container">
					<div class="row align-items-center">
						<div class="col-md-12 pb-50 header-text text-center">
							<h1 class="mb-10">Team Members</h1>
						</div>	
						  <img style="width: 100%;" src="img/content/team.jpg">
						
					
					</div>
				</div>	
			</section>
			<!---  End Service  -->			
			<!------ Contact us 
			
			<section class="project-details-area section-gap full_section" id="portfolio">
			<div class="col-md-12 pb-50 header-text text-center">
							<h1 class="mb-10">Portfolio</h1>
						</div>	
				<div class="container full_right" style="max-width: 1350px;">
					<div class="row align-items-center">
						<div class="col-lg-6 project-details-left full_left">
						    <p style="color:white;">Portfolio</p>
							<h1 class="pb-20" style="color:white;">Take your business to the next level</h1>
							<div class="arrow">
							<img src="img/Extra/arrow.png">
							</div>
						</div>
						<div class="col-lg-6 project-details-right ">
							<h1 class="pb-20" style="color:white;margin-top: 24px;margin-left: 40px;">Explore your Work</h1>
							<p class="business_next">We completely understand your business needs and create a website design which is innovative, unique and makes you stand apart from the crowd.</p>
							<p class="business_next">We create clear design and visuals that compel enough for visitors to stay on the page.</p>
							<p class="business_next">We distinguish you from your competitors by adding distinct selling points to your customer base of an amazing combination of good design, enhanced functionality, graphics, and content.</p>
							<p class="business_next">We work diligently to fulfill your dream of having a unique brand, identity, and recognition and guarantee 100% satisfaction with the results.</p>
																			
						</div>
					</div>
				</div>	
			</section>
			
		 End Contact us ------->
			
			
			
			
			
			 <!-- Modal -->
<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          
        </div>
        <div class="modal-body">
            
<div class="form-group">
  <label>Types of Website</label>
  <select name="form_change" id="form_change" class="form-control">
    <option value="">Select one </option>
    <option value="1">Static Website</option>
    <option value="2">Dynamic Website</option>
	</select>
</div>
<form>
<div style="display:none;" id="static">
<div class="form-group">
<p>Per Page: 2000 &#8377;</p>
  <label>Amount Of Pages</label>
  <input type="number" class="form-control" id="text"><span><button id="calc" class="click-btn btn btn-default"><b>></b></button></span>
  <label>Total Cost : Rs.</label>  <label>0</label>
  </div>
</div>

<div style="display:none;" id="dynamic">
<div class="form-group">
<p>Per Page: 2000 &#8377;</p>
  <label>Amount Of Pages</label>
  <input type="number" class="form-control" id="text"><span> <button id="calc" class="click-btn btn btn-default"><b>></b></button></span>
  <label>Total Cost : Rs.</label>  <label>0</label>
  
  </div>
</div>

</form>
        </div>
        <div class="modal-footer">
		<button type="button" class="btn btn-default" data-dismiss="modal" >Want to know more!</button>
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
		 
        </div>
      </div>
      
    </div>
</div>

		 <script>jQuery(function($) {
    $('#myModal').on('hidden.bs.modal', function (e) {
        $('html, body').animate({
            scrollTop: $("#contact").offset().bottom
        }, 2000);
    })
});
</script> 
   <!-- End Modal -->
	<div class="clearfix">	</div>
			
			
			<!-- start footer Area -->
<footer class="footer-area section-gap" id="contact">
				<div class="container" >
					<div class="row" style="background-color:#91dfcfa3; color:#171616;padding-top: 26px;padding-bottom: 26px;" >
						<div class="col-lg-5 col-md-6 col-sm-6">
							<div class="single-footer-widget" style="
    background-color: #c7eef3;
    padding: 8px;
    
">
								<h6>Address</h6>
								<p>
								501, Milan R1 Society, <br/>Opp. Gangatara Buld. <br/>Shashtri nagar, <br/>Sahakar Nagar, <br/>Thane(W) 400600.
								</p>
								<p><i class="fa fa-envelope-o" aria-hidden="true"></i> satyammauryask1716@gmail.com</p>
																
							</div>
						</div>
						<div class="col-lg-5  col-md-6 col-sm-6">
							<div class="single-footer-widget" style="
    background-color: #c7eef3;
    padding: 8px;
    
">
								<h6>Connect With Us!</h6>
								
								<div class="" id="mc_embed_signup">
									<form action="mail.php" method="POST" >
									<input class="form-control space" name="name" placeholder=" Name" onfocus="this.placeholder = ''" onblur="this.placeholder = 'name'" required="" type="text">
									
										<input class="form-control space" name="email" placeholder="Email" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Email'" required="" type="email">
										<input class="form-control space" name="phone" placeholder="Phone" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Phone'" required="" type="number">
										<input class="form-control space" name="subject" placeholder="Message" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Message'" required="" type="text">
										
										<br>
			                            	<button class="click-btn btn btn-default" style="margin-top: -10px;"><i class="lnr lnr-arrow-right" aria-hidden="true"></i></button>
			                            	
									</form>
								</div>
							</div>
						</div>						
						<div class="col-lg-2 col-md-6 col-sm-6 social-widget">
							<div class="single-footer-widget" style="
    background-color: #c7eef3;
    padding: 8px;
    
">
								<h6>Follow Us</h6>
								<p>Let us be social</p>
								<p><i class="fa fa-whatsapp" aria-hidden="true" style="font-size: 15px;"></i> 8976353808</p>
								<p><i class="fa fa-mobile" aria-hidden="true" style="font-size: 17px;"></i> 8080922244</p>
								
								<div class="footer-social d-flex align-items-center">
									<a href="#"><i class="fa fa-facebook"></i></a>
									<a href="#"><i class="fa fa-twitter"></i></a>
									<a href="#"><i class="fa fa-dribbble"></i></a>
									<a href="#"><i class="fa fa-behance"></i></a>
								</div>
							</div>
						</div>		
                       					
					</div>
				</div>
			</footer>
			 <div class="col-md-12 col-sm-12">
						  <p class="footer-text">
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | <a href="#" target="_blank">Satyam Softwares</a>. </p>
                        </div> 	
			
			<!-- End footer Area -->	

			<script src="js/vendor/jquery-2.2.4.min.js"></script>
			<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
			<script src="js/vendor/bootstrap.min.js"></script>			
			<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBhOdIF3Y9382fqJYt5I_sswSrEw5eihAA"></script>
  			<script src="js/easing.min.js"></script>			
			<script src="js/hoverIntent.js"></script>
			<script src="js/superfish.min.js"></script>	
			<!--<script src="js/jquery.ajaxchimp.min.js"></script>-->
			<script src="js/jquery.magnific-popup.min.js"></script>	
			<script src="js/owl.carousel.min.js"></script>						
			<script src="js/jquery.nice-select.min.js"></script>							
		<!-- <script src="js/mail-script.js"></script>	-->
			<script src="js/main.js"></script>	
			<script src="js/javascript.js"></script>
			<!-- end footer Area -->		

		</body>
	</html>